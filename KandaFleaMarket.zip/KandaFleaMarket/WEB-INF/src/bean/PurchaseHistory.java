package bean;

public class PurchaseHistory {

	private int purchaseHistoryId;// 売上げID
	private int sellerId;// 出品者ID
	private String nickname; // 出品者 ニックネーム
	private int itemId;// 商品ID
	private String itemName;// 商品名
	private String remarks;// 商品説明
	private int price;// 購入価格
	private String picture;// 画像パス
	private int buyerId;// 購入者ID
	private String purchaseDate; // 購入日時
	private int sendStatus; // 発送状況

	// コンストラクタ（初期化）
	public PurchaseHistory() {
		this.purchaseHistoryId = 0;
		this.sellerId = 0;
		this.nickname = null;
		this.itemId = 0;
		this.itemName = null;
		this.remarks = null;
		this.price = 0;
		this.picture = null;
		this.buyerId = 0;
		this.purchaseDate = null;
		this.sendStatus = 0;

	}

	public int getPurchaseHistoryId() {
		return purchaseHistoryId;
	}

	public void setPurchaseHistoryId(int purchaseHistoryId) {
		this.purchaseHistoryId = purchaseHistoryId;
	}

	public int getSellerId() {
		return sellerId;
	}

	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public int getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(int buyerId) {
		this.buyerId = buyerId;
	}

	public String getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(String purchaseDate) {
		this.purchaseDate = purchaseDate;
	}

	public int getSendStatus() {
		return sendStatus;
	}

	public void setSendStatus(int sendStatus) {
		this.sendStatus = sendStatus;
	}
}
