/*
 * プログラム名：フリマサイト(Item.java)
 * プログラムの説明：Item（商品）を管理するDTOクラス
 * 作成者：駒田夏帆
 * 作成日：2022年6月16日
 */

package bean;

public class Item {

	// 引数なしコンストラクタ
	private int itemId; // 商品ID
	private int sellerId; // 出品者のユーザーID
	private String itemName; // 商品名
	private int itemTypeId; // 商品種類ID
	private int quantity; // 個数
	private int price; // 販売価格（送料込み）
	private String remarks; // 商品説明
	private int itemStatus; // 商品状態（1.未使用、2.良、3.やや傷・汚れあり、4.不良）
	private String picture; // 画像
	private String itemInsertDate; // 出品日時
	private String updateDate; // 更新日時
	private int salesStatus; // 販売状態（1.完売、2.販売中、3.非表示）

	// 引数なしコンストラクタ
	public Item() {
		setItemId(0);
		setSellerId(0);
		setItemName(null);
		setItemTypeId(0);
		setQuantity(0);
		setPrice(0);
		setRemarks(null);
		setItemStatus(0);
		setPicture(null);
		setItemInsertDate(null);
		setUpdate_date(null);
		setSalesStatus(0);
	}

	// アクセサメソッド
	// 商品ID
	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	// 出品者のユーザーID
	public int getSellerId() {
		return sellerId;
	}

	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}

	// 商品名
	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	// 商品種類ID
	public int getItemTypeId() {
		return itemTypeId;
	}

	public void setItemTypeId(int itemTypeId) {
		this.itemTypeId = itemTypeId;
	}

	// 個数
	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	// 販売価格（送料込み）
	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	// 商品説明
	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	// 商品状態（1.未使用、2.良、3.やや傷・汚れあり、4.不良）
	public int getItemStatus() {
		return itemStatus;
	}

	public void setItemStatus(int itemStatus) {
		this.itemStatus = itemStatus;
	}

	// 画像
	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	// 出品日時
	public String getItemInsertDate() {
		return itemInsertDate;
	}

	public void setItemInsertDate(String itemInsertDate) {
		this.itemInsertDate = itemInsertDate;
	}

	// 更新日時
	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdate_date(String updateDate) {
		this.updateDate = updateDate;
	}

	// 販売状態（1.完売、2.販売中、3.非表示）
	public int getSalesStatus() {
		return salesStatus;
	}

	public void setSalesStatus(int salesStatus) {
		this.salesStatus = salesStatus;
	}
}
