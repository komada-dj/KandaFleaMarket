package bean;

public class Purchase {

	private int profitId;
	private int itemId;
	private int sellerId;
	private String sellerNickname;
	private String itemName;
	private int itemTypeId;
	private int quantity;
	private int price;
	private String remarks;
	private int itemStatus;
	private String picture;
	private int buyerId;
	private String buyerNickname;
	private String buyDate;
	private int paymentStatus;
	private String paymentDate;
	private int sendStatus;
	private String sendDate;

	//初期設定
	public Purchase() {
		this.profitId = 0;
		this.itemId = 0;
		this.sellerId = 0;
		this.sellerNickname = null;
		this.itemName = null;
		this.itemTypeId = 0;
		this.quantity = 0;
		this.price = 0;
		this.remarks = null;
		this.itemStatus = 0;
		this.picture = null;
		this.buyerId = 0;
		this.buyerNickname = null;
		this.buyDate = null;
		this.paymentStatus = 0;
		this.paymentDate = null;
		this.sendStatus = 0;
		this.sendDate = null;
	}

	//アクセサメソッド
	public int getProfitId() {
		return profitId;
	}

	public void setProfitId(int profitId) {
		this.profitId = profitId;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public int getSellerId() {
		return sellerId;
	}

	public void setSellerId(int sellerId) {
		this.sellerId = sellerId;
	}

	public String getSellerNickname() {
		return sellerNickname;
	}

	public void setSellerNickname(String sellerNickname) {
		this.sellerNickname = sellerNickname;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public int getItemTypeId() {
		return itemTypeId;
	}

	public void setItemTypeId(int itemTypeId) {
		this.itemTypeId = itemTypeId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public int getItemStatus() {
		return itemStatus;
	}

	public void setItemStatus(int itemStatus) {
		this.itemStatus = itemStatus;
	}

	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public int getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(int buyerId) {
		this.buyerId = buyerId;
	}

	public String getBuyerNickname() {
		return buyerNickname;
	}

	public void setBuyerNickname(String buyerNickname) {
		this.buyerNickname = buyerNickname;
	}

	public String getBuyDate() {
		return buyDate;
	}

	public void setBuyDate(String buyDate) {
		this.buyDate = buyDate;
	}

	public int getPaymentStatus() {
		return paymentStatus;
	}

	public void setPaymentStatus(int paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public String getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}

	public int getSendStatus() {
		return sendStatus;
	}

	public void setSendStatus(int sendStatus) {
		this.sendStatus = sendStatus;
	}

	public String getSendDate() {
		return sendDate;
	}

	public void setSendDate(String sendDate) {
		this.sendDate = sendDate;
	}

}
