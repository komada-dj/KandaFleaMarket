package bean;

public class Favorite {

	private int favoriteId; // お気に入りID
	private int userId; // 登録者ID
	private int itemId; // 商品ID
	private String itemName;// 商品名
	private int price;// 販売価格
	private String remarks;// 商品説明
	private String picture;// 画像パス
	private String registerDate;// 登録日時

	// コンストラクタ(初期化）
	public Favorite() {
		this.favoriteId = 0;
		this.userId = 0;
		this.itemId = 0;
		this.itemName = null;
		this.price = 0;
		this.remarks = null;
		this.picture = null;
		this.registerDate = null;
	}

	// 各setter getterメソッド

	public int getFavoriteId() {
		return favoriteId;
	}

	public void setFavoriteId(int favoriteId) {
		this.favoriteId = favoriteId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public String getregisterDate() {
		return registerDate;
	}

	public void setregisterDate(String registerDate) {
		this.registerDate = registerDate;
	}
}
