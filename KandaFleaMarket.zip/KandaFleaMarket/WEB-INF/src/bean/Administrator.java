/*
 * プログラム名：フリマサイト(Administrator.java)
 * プログラムの説明：Administrator（管理者）を管理するDTOクラス
 * 作成者：駒田夏帆
 * 作成日：2022年6月16日
 */

package bean;

public class Administrator {

	private int administratorId; // 管理者ID
	private String name; // 名前
	private String mail; // メールアドレス
	private String password; // パスワード

	// 引数なしコンストラクタ
	public Administrator() {
		setAdministratorId(0);
		setName(null);
		setMail(null);
		setPassword(null);
	}

	// アクセサメソッド
	// 管理者ID
	public int getAdministratorId() {
		return administratorId;
	}

	public void setAdministratorId(int administratorId) {
		this.administratorId = administratorId;
	}

	// 名前
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	// メールアドレス
	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	// パスワード
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
