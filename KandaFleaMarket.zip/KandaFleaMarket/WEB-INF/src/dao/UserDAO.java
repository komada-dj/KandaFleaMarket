package dao;

import java.sql.*;
import java.util.*;

import bean.User;


/**
 * SQL接続
 *
 * @author
 *
 */

public class UserDAO {
	private static final String RDB_DRIVE = "com.mysql.jdbc.Driver";

	private static final String URL = "jdbc:mysql://localhost/kanda_freemarketdb";

	private static final String USER = "root";

	private static final String PASSWD = "root123";

	/**
	 *
	 * @return
	 */

	private static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName(RDB_DRIVE);
			con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	/**おそらくログイン機能に関係している
	 *
	 * @param mail
	 * @param password
	 * @return
	 */
	public User selectByUser (String mail, String password) {
		User user = new User();
		Connection con = null;
		Statement smt = null;

		try {
			con = getConnection();
			smt = con.createStatement();
			String sql = "SELECT * FROM userinfo WHERE mail ='"+ user.getMail() +"' AND password='"+ user.getPassword() +"'";
			ResultSet rs = smt.executeQuery(sql);

			if (rs.next()) {
				user.setUserId(rs.getInt("uesr_id"));
				user.setPassword(rs.getString("password"));
				user.setMail(rs.getString("mail"));
				user.setNickname("nickname");
				user.setBirthday(rs.getDate("birthday"));
				user.setPassword(rs.getString("password"));
				user.setPostCode(rs.getString("post_code"));
				user.setItemJudge(rs.getInt("item_judge"));
				user.setSituation(rs.getInt("situation"));
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return user;

		}

/**
 * 全ユーザーを取得
 * @return
 */
	public ArrayList<User> selectAll() {
		Connection con = null;
		Statement smt = null;
		ArrayList<User> userList = new ArrayList<User>();

		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "select * from userinfo";
			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				User user = new User();
				user.setUserId(rs.getInt("uesrId"));
				user.setPassword(rs.getString("password"));
				user.setMail(rs.getString("mail"));
				user.setNickname("nickname");
				user.setBirthday(rs.getDate("birthday"));
				user.setPassword(rs.getString("password"));
				user.setPostCode(rs.getString("postCode"));
				user.setItemJudge(rs.getInt("itemJudge"));
				user.setSituation(rs.getInt("situation"));
				userList.add(user);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return userList;
	}

	/**
	 * とうろく
	 *
	 * @param user
	 */
	public void insert(User user) {
		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "insert into userinfo values(null,'" + user.getName() + "','"
			+ user.getNickname() + "','" + user.getMail() + "','" + user.getBirthday()
			+ "','" + user.getPassword() + "','" + user.getPostCode() + "','"
			+ user.getAddress() +")";

			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	/**削除
	 *
	 */
	public void delete(int userId ) {
		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "delete from userinfo where user_id = '"+ userId + "'";

			smt.executeUpdate(sql);
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}
	/**変更
	 *
	 * @param user
	 */
	public void update(User user) {
		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "UPDATE userinfo SET user_id='\"+user.getUser_id()+\"',name='"+ user.getName() +"',nickname="+ user.getNickname()+"',mail=" + user.getMail()
			+"',birthday="+ user.getBirthday()+"',password=" + user.getPassword()+"',post_code=" + user.getPostCode()
			+"',address=" + user.getAddress() + " WHERE ='"+ user.getUserId()+"'";


			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	/**
	 *
	 * @param
	 * @return
	 */

	public User selectByUser(String mail) {
		User user = new User();
		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();
			String sql = "select * from userinfo where mail = '" + mail + "'";
			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				user.setUserId(rs.getInt("uesrId"));
				user.setPassword(rs.getString("password"));
				user.setMail(rs.getString("mail"));
				user.setNickname("nickname");
				user.setBirthday(rs.getDate("birthday"));
				user.setPassword(rs.getString("password"));
				user.setPostCode(rs.getString("postCode"));
				user.setItemJudge(rs.getInt("itemJudge"));
				user.setSituation(rs.getInt("situation"));
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return user;
	}

	/**
	 *
	 * @param
	 * @return
	 */

	public User selectByUser(int userId ) {
		User user = new User();
		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();
			String sql = "select * from userinfo where mail = '" + userId + "'";
			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				user.setUserId(rs.getInt("uesrId"));
				user.setPassword(rs.getString("password"));
				user.setMail(rs.getString("mail"));
				user.setNickname(rs.getString("nickname"));
				user.setBirthday(rs.getDate("birthday"));
				user.setPassword(rs.getString("password"));
				user.setPostCode(rs.getString("postCode"));
				user.setItemJudge(rs.getInt("itemJudge"));
				user.setSituation(rs.getInt("situation"));
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return user;
	}
}