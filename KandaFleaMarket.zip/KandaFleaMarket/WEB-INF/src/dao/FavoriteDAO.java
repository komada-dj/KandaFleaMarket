package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import bean.Favorite;

public class FavoriteDAO {

	// DB接続
	private static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static String URL = "jdbc:mysql://localhost/kanda_freemarket";
	private static String USER = "root";
	private static String PASSWD = "root123";

	public static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	// お気に入り登録メソッド
	public void insert(Favorite favorite) {

		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();
			// sql要確認（コピペしましたがあってるか不安です）
			String sql = "insert into favoriteinfo values(null,'" + favorite.getUserId() + "','" + favorite.getItemId()
			+ "','" + favorite.getregisterDate() + ")";

			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	// お気に入り一覧メソッド
	public Favorite selectByUserId(int userId) {
		Favorite favorite = new Favorite();
		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();
			// sql要確認
			String sql = "SELECT * FROM favoriteinfo INNER JOIN typeinfo ON iteminfo.item_id=typeinfo.item_id";

			ResultSet rs = smt.executeQuery(sql);

			if (rs.next()) {
				favorite.setFavoriteId(rs.getInt("favorite_id"));
				favorite.setUserId(rs.getInt("user_id"));
				favorite.setItemId(rs.getInt("item_id"));
				favorite.setItemName(rs.getString("item_name"));
				favorite.setPrice(rs.getInt("price"));
				favorite.setRemarks(rs.getString("remarks"));
				favorite.setRemarks(rs.getString("picture"));
				favorite.setregisterDate(rs.getString("register_date"));
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return favorite;
	}

	// お気に入り削除メソッド
	public void delete(int favoriteId) {
		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();
			// sql要確認
			String sql = "delete from favoriteinfo where favorite_id = '" + favoriteId + "'";
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

}