package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.Sales;
import bean.User;

import java.util.Date;

public class SalesDAO {

	/**
	 * SQL接続
	 *
	 * @author
	 *
	 */

		private static final String RDB_DRIVE = "com.mysql.jdbc.Driver";

		private static final String URL = "jdbc:mysql://localhost/kanda_freemarketdb";

		private static final String USER = "root";

		private static final String PASSWD = "root123";

		/**
		 *
		 * @return
		 */

		private static Connection getConnection() {
			Connection con = null;
			try {
				Class.forName(RDB_DRIVE);
				con = DriverManager.getConnection(URL, USER, PASSWD);
				return con;
			} catch (Exception e) {
				throw new IllegalStateException(e);
			}
		}

		/**
		 * 全売上を取得
		 * @return
		 */
			public ArrayList<Sales> selectAll() {
				Connection con = null;
				Statement smt = null;
				ArrayList<Sales> salesList = new ArrayList<Sales>();

				try {
					con = getConnection();
					smt = con.createStatement();

					String sql = "select * from profitinfo";
					ResultSet rs = smt.executeQuery(sql);

					while (rs.next()) {
						Sales sales = new Sales();
						sales.setProfitId(rs.getInt("profitId"));
						sales.setUserId(rs.getInt("itemId"));
						sales.setPrice(rs.getInt("price"));
						sales.setUserId(rs.getInt("userId"));
						sales.setPurchaseDate(rs.getString("purchaseDate"));
						sales.setPaymentStatus(rs.getInt("paymentStatus"));
						sales.setSendStatus(rs.getInt("sendStatus"));
						sales.setPaymentDate(rs.getString("paymentDate"));
						sales.setSendDate(rs.getString("sendDate"));

						salesList.add(sales);
					}

				} catch (Exception e) {
					throw new IllegalStateException(e);
				} finally {
					if (smt != null) {
						try {
							smt.close();
						} catch (SQLException ignore) {
						}
					}
					if (con != null) {
						try {
							con.close();
						} catch (SQLException ignore) {
						}
					}
				}
				return salesList;
			}

			/**指定年月の売上表示
			 *出来てません
			 */

			//sql = "select * from profitinfo where month="xxxxx";



			/**指定年月・指定ユーザーの売上表示
			 *出来てません
			 */
			//sql = "select * from profitinfo where year= "xxxx" month="xxxxx" name="xxxx"";

}

