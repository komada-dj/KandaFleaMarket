/*
 * プログラム名：フリマサイト(AdministratorDTO.java)
 * プログラムの説明：Administrator（管理者）情報についてデータベース接続するDAOクラス
 * 作成者：駒田夏帆
 * 作成日：2022年6月16日
 */

package dao;

import java.sql.*;
import java.util.*;

import bean.Administrator;

public class AdministratorDAO {

	// 接続用の情報をフィールドに定数として定義
	private static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static String URL = "jdbc:mysql://localhost/kanda_freemarket";
	private static String USER = "root";
	private static String PASSWD = "root123";

	// データベース接続を行うメソッド
	public static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	// DBのadministratorinfoテーブルから指定ユーザーIDの条件に合致する情報を取得するメソッド
	public Administrator selectByAdministratorId(int administrator_id) {
		// 変数宣言
		Connection con = null;
		Statement smt = null;

		// return用ｵﾌﾞｼﾞｪｸﾄ宣言
		Administrator administrator = new Administrator();

		// SQL文
		String sql = "select * from administratorinfo where administrator_id= '" + administrator_id + "'";

		try {
			con = getConnection();
			smt = con.createStatement();

			// SQLをDBへ発行
			ResultSet rs = smt.executeQuery(sql);

			// 取得した結果をDTOオブジェクトに格納
			if (rs.next()) {
				administrator.setAdministratorId(rs.getInt("administrator_id"));
				administrator.setName(rs.getString("name"));
				administrator.setMail(rs.getString("mail"));
				administrator.setPassword(rs.getString("password"));
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);

		} finally {
			// リソースの開放
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return administrator;
	}

	// DBのadministratorinfoテーブルから指定メールアドレスとパスワードの条件に合致する情報を取得するメソッド
	public Administrator selectByMailPassword(String mail, String password) {
		// 変数宣言
		Connection con = null;
		Statement smt = null;

		// return用ｵﾌﾞｼﾞｪｸﾄ宣言
		Administrator administrator = new Administrator();

		// SQL文
		String sql = "SELECT * FROM administratorinfo WHERE mail ='" + mail + "' AND password='" + password + "'";

		try {
			con = getConnection();
			smt = con.createStatement();

			// SQLをDBへ発行
			ResultSet rs = smt.executeQuery(sql);

			// 取得した結果をDTOオブジェクトに格納
			if (rs.next()) {
				administrator.setAdministratorId(rs.getInt("administrator_id"));
				administrator.setName(rs.getString("name"));
				administrator.setMail(rs.getString("mail"));
				administrator.setPassword(rs.getString("password"));
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);

		} finally {
			// リソースの開放
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return administrator;
	}
}
