/*
 * プログラム名：フリマサイト(ItemDAO.java)
 * プログラムの説明：Item（商品）情報についてデータベース接続するDAOクラス
 * 作成者：駒田夏帆
 * 作成日：2022年6月16日
 */

package dao;

import java.sql.*;
import java.util.*;

import bean.Item;

public class ItemDAO {

	// 接続用の情報をフィールドに定数として定義
	private static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static String URL = "jdbc:mysql://localhost/kanda_freemarket";
	private static String USER = "root";
	private static String PASSWD = "root123";

	// データベース接続を行うメソッド
	public static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	// DBのiteminfoテーブルからから商品データを検索しArrayListオブジェクトに格納するメソッド（商品ID昇順）
	public ArrayList<Item> selectAll() {

		ArrayList<Item> item_list = new ArrayList<Item>();
		String sql = "SELECT * FROM iteminfo ORDER BY item_id";

		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();

			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				Item item = new Item();

				item.setItemId(rs.getInt("item_id"));
				item.setSellerId(rs.getInt("seller_id"));
				item.setItemName(rs.getString("item_name"));
				item.setItemTypeId(rs.getInt("item_type_id"));
				item.setQuantity(rs.getInt("quantity"));
				item.setPrice(rs.getInt("price"));
				item.setRemarks(rs.getString("remarks"));
				item.setItemStatus(rs.getInt("item_status"));
				item.setPicture(rs.getString("picture"));
				item.setItemInsertDate(rs.getString("item_insert_date"));
				item.setUpdate_date(rs.getString("update_date"));
				item.setSalesStatus(rs.getInt("sales_status"));

				item_list.add(item);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);

		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return item_list;

	}

	// DBのiteminfoテーブルから販売中の商品情報を取得するメソッド
	public Item selectNowOn(int sales_status) {
		// 変数宣言
		Connection con = null;
		Statement smt = null;

		// return用ｵﾌﾞｼﾞｪｸﾄ宣言
		Item item = new Item();

		// SQL文
		String sql = "SELECT * FROM iteminfo WHERE sales_status ='" + 2 + "'";

		try {
			con = getConnection();
			smt = con.createStatement();

			// SQLをDBへ発行
			ResultSet rs = smt.executeQuery(sql);

			// 取得した結果をDTOオブジェクトに格納
			if (rs.next()) {
				item.setItemId(rs.getInt("item_id"));
				item.setSellerId(rs.getInt("seller_id"));
				item.setItemName(rs.getString("item_name"));
				item.setItemTypeId(rs.getInt("item_type_id"));
				item.setQuantity(rs.getInt("quantity"));
				item.setPrice(rs.getInt("price"));
				item.setRemarks(rs.getString("remarks"));
				item.setItemStatus(rs.getInt("item_status"));
				item.setPicture(rs.getString("picture"));
				item.setItemInsertDate(rs.getString("item_insert_date"));
				item.setUpdate_date(rs.getString("update_date"));
				item.setSalesStatus(rs.getInt("sales_status"));

			}

		} catch (Exception e) {
			throw new IllegalStateException(e);

		} finally {
			// リソースの開放
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return item;
	}

	// DBのiteminfoテーブルから指定した商品IDの条件に合致する商品情報を取得するメソッド
	public Item selectByItemId(int item_id) {
		// 変数宣言
		Connection con = null;
		Statement smt = null;

		// return用ｵﾌﾞｼﾞｪｸﾄ宣言
		Item item = new Item();

		// SQL文
		String sql = "select * from iteminfo where item_id= '" + item_id + "'";

		try {
			con = getConnection();
			smt = con.createStatement();

			// SQLをDBへ発行
			ResultSet rs = smt.executeQuery(sql);

			// 取得した結果をDTOオブジェクトに格納
			if (rs.next()) {
				item.setItemId(rs.getInt("item_id"));
				item.setSellerId(rs.getInt("seller_id"));
				item.setItemName(rs.getString("item_name"));
				item.setItemTypeId(rs.getInt("item_type_id"));
				item.setQuantity(rs.getInt("quantity"));
				item.setPrice(rs.getInt("price"));
				item.setRemarks(rs.getString("remarks"));
				item.setItemStatus(rs.getInt("item_status"));
				item.setPicture(rs.getString("picture"));
				item.setItemInsertDate(rs.getString("item_insert_date"));
				item.setUpdate_date(rs.getString("update_date"));
				item.setSalesStatus(rs.getInt("sales_status"));
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);

		} finally {
			// リソースの開放
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return item;
	}

	// DBのiteminfoテーブルから指定した出品者IDの条件に合致する商品情報を取得するメソッド
	public Item selectByUserId(int user_id) {
		// 変数宣言
		Connection con = null;
		Statement smt = null;

		// return用ｵﾌﾞｼﾞｪｸﾄ宣言
		Item item = new Item();

		// SQL文
		String sql = "select * from iteminfo where user_id= '" + user_id + "'";

		try {
			con = getConnection();
			smt = con.createStatement();

			// SQLをDBへ発行
			ResultSet rs = smt.executeQuery(sql);

			// 取得した結果をDTOオブジェクトに格納
			if (rs.next()) {
				item.setItemId(rs.getInt("item_id"));
				item.setSellerId(rs.getInt("seller_id"));
				item.setItemName(rs.getString("item_name"));
				item.setItemTypeId(rs.getInt("item_type_id"));
				item.setQuantity(rs.getInt("quantity"));
				item.setPrice(rs.getInt("price"));
				item.setRemarks(rs.getString("remarks"));
				item.setItemStatus(rs.getInt("item_status"));
				item.setPicture(rs.getString("picture"));
				item.setItemInsertDate(rs.getString("item_insert_date"));
				item.setUpdate_date(rs.getString("update_date"));
				item.setSalesStatus(rs.getInt("sales_status"));
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);

		} finally {
			// リソースの開放
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return item;
	}

	// DBのiteminfoテーブルのうち、出品中の中から指定した出品者IDの条件に合致する商品情報を取得するメソッド
	public Item selectNowOnByUserId(int user_id) {
		// 変数宣言
		Connection con = null;
		Statement smt = null;

		// return用ｵﾌﾞｼﾞｪｸﾄ宣言
		Item item = new Item();

		// SQL文
		String sql = "SELECT * FROM iteminfo WHERE sales_status ='" + 2 + "' AND user_id='" + user_id + "'";

		try {
			con = getConnection();
			smt = con.createStatement();

			// SQLをDBへ発行
			ResultSet rs = smt.executeQuery(sql);

			// 取得した結果をDTOオブジェクトに格納
			if (rs.next()) {
				item.setItemId(rs.getInt("item_id"));
				item.setSellerId(rs.getInt("seller_id"));
				item.setItemName(rs.getString("item_name"));
				item.setItemTypeId(rs.getInt("item_type_id"));
				item.setQuantity(rs.getInt("quantity"));
				item.setPrice(rs.getInt("price"));
				item.setRemarks(rs.getString("remarks"));
				item.setItemStatus(rs.getInt("item_status"));
				item.setPicture(rs.getString("picture"));
				item.setItemInsertDate(rs.getString("item_insert_date"));
				item.setUpdate_date(rs.getString("update_date"));
				item.setSalesStatus(rs.getInt("sales_status"));
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);

		} finally {
			// リソースの開放
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return item;
	}

	// DBのiteminfoテーブルへ商品データを登録するメソッド
	public void insert(Item item) {
		// 変数宣言
		Connection con = null;
		Statement smt = null;

		// SQL文
		String sql = "INSERT INTO iteminfo VALUES('" + item.getItemId() + "','" + item.getSellerId() + "','"
				+ item.getItemName() + "','" + item.getItemTypeId() + "','" + item.getQuantity() + "','"
				+ item.getPrice() + "','" + item.getRemarks() + "','" + item.getItemStatus() + "','"
				+ item.getPicture() + "','" + item.getItemInsertDate() + "','" + item.getUpdateDate() + "','"
				+ item.getSalesStatus() + "')";

		try {
			con = getConnection();
			smt = con.createStatement();

			// SQLをDBへ発行
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			// リソースの開放
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	// DBのiteminfoテーブルについて商品データを更新するメソッド
	public void update(Item item) {
		// 変数宣言
		Connection con = null;
		Statement smt = null;

		// SQL文
		String sql = "UPDATE account SET "
					+ "seller_id = '" + item.getSellerId() + "', "
					+ "item_name = '"+ item.getItemName() + "', "
					+ "item_type_id = '"+ item.getItemTypeId() + "', "
					+ "quantity = '"+ item.getQuantity() + "', "
					+ "price = '"+ item.getPrice() + "', "
					+ "remarks = '"+ item.getRemarks() + "', "
					+ "item_status = '"+ item.getItemStatus() + "', "
					+ "item_picture = '"+ item.getPicture() + "', "
					+ "item_insert_date = '"+ item.getItemInsertDate() + "', "
					+ "item_update_date = '"+ item.getUpdateDate() + "', "
					+ "sales_status = '"+ item.getSalesStatus() + "'"
					+ "WHERE item_id = '" + item.getItemId() + "'";

		try {
			con = getConnection();
			smt = con.createStatement();

			// SQLをDBへ発行
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);

		} finally {
			// リソースの開放
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	// DBのiteminfoテーブルについて商品データを削除するメソッド
	public void delete(int item_id) {
		// 変数宣言
		Connection con = null;
		Statement smt = null;

		// SQL文
		String sql = "DELETE FROM iteminfo WHERE item_id = '" + item_id + "'";

		try {
			con = getConnection();
			smt = con.createStatement();

			// SQLをDBへ発行
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);

		} finally {
			// リソースの開放
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	// DBのiteminfoテーブルから商品情報の検索を行うメソッド
	public ArrayList<Item> search(int item_type_id, String item_name) {
		// 変数宣言
		Connection con = null;
		Statement smt = null;

		// return用オブジェクトの生成
		ArrayList<Item> item_list = new ArrayList<Item>();

		// SQL文
		String sql = "SELECT * FROM iteminfo " +"WHERE sales_status = 2 AND item_type_id LIKE '%" + item_type_id + "%' AND item_name LIKE '%" + item_name + "%'";

		try {
			con = getConnection();
			smt = con.createStatement();

			// SQLをDBへ発行
			ResultSet rs = smt.executeQuery(sql);

			// 検索結果を配列に格納
			while (rs.next()) {
				Item item = new Item();

				item.setItemId(rs.getInt("item_id"));
				item.setSellerId(rs.getInt("seller_id"));
				item.setItemName(rs.getString("item_name"));
				item.setItemTypeId(rs.getInt("item_type_id"));
				item.setQuantity(rs.getInt("quantity"));
				item.setPrice(rs.getInt("price"));
				item.setRemarks(rs.getString("remarks"));
				item.setItemStatus(rs.getInt("item_status"));
				item.setPicture(rs.getString("picture"));
				item.setItemInsertDate(rs.getString("item_insert_date"));
				item.setUpdate_date(rs.getString("update_date"));
				item.setSalesStatus(rs.getInt("sales_status"));

				item_list.add(item);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			// リソースの開放
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return item_list;
	}
}
