package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.PurchaseHistory;

public class PurchaseHistoryDAO {
	// DB接続
	private static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static String URL = "jdbc:mysql://localhost/kanda_freemarket";
	private static String USER = "root";
	private static String PASSWD = "root123";

	public static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	// 全選択
	public ArrayList<PurchaseHistory> selectAll() {
		Connection con = null;
		Statement smt = null;
		ArrayList<PurchaseHistory> purchaseHistoriesList = new ArrayList<PurchaseHistory>();

		try {
			con = getConnection();
			smt = con.createStatement();

			String sql = "SELECT * FROM purchase_history ORDER BY purchase_history_id";
			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				PurchaseHistory purchaseHistory = new PurchaseHistory();
				purchaseHistory.setPurchaseHistoryId(rs.getInt("purchase_history_id"));
				purchaseHistory.setSellerId(rs.getInt("seller_id"));
				purchaseHistory.setNickname(rs.getString("nickname"));
				purchaseHistory.setItemId(rs.getInt("item_id"));
				purchaseHistory.setItemName(rs.getString("item_name"));
				purchaseHistory.setRemarks(rs.getString("remarks"));
				purchaseHistory.setPrice(rs.getInt("price"));
				purchaseHistory.setPicture(rs.getString("picture"));
				purchaseHistory.setBuyerId(rs.getInt("buyer_id"));
				purchaseHistory.setPurchaseDate(rs.getString("purchase_date"));
				purchaseHistory.setSendStatus(rs.getInt("send_status"));
				purchaseHistoriesList.add(purchaseHistory);

			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return purchaseHistoriesList;
	}

	public PurchaseHistory selectByBuyerId(int buyerId) {

		PurchaseHistory purchaseHistory = new PurchaseHistory();
		Connection con = null;
		Statement smt = null;
		try {
			con = getConnection();
			smt = con.createStatement();
			// sql要確認
			String sql = "SELECT * FROM purchase_history WHERE purchase_history_id ='\" + purchase_history_id + \"'";
			ResultSet rs = smt.executeQuery(sql);

			if (rs.next()) {
				purchaseHistory.setPurchaseHistoryId(rs.getInt("purchase_history_id"));
				purchaseHistory.setSellerId(rs.getInt("seller_id"));
				purchaseHistory.setNickname(rs.getString("nickname"));
				purchaseHistory.setItemId(rs.getInt("item_id"));
				purchaseHistory.setItemName(rs.getString("item_name"));
				purchaseHistory.setRemarks(rs.getString("remarks"));
				purchaseHistory.setPrice(rs.getInt("price"));
				purchaseHistory.setPicture(rs.getString("picture"));
				purchaseHistory.setBuyerId(rs.getInt("buyer_id"));
				purchaseHistory.setPurchaseDate(rs.getString("purchase_date"));
				purchaseHistory.setSendStatus(rs.getInt("send_status"));
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return purchaseHistory;
	}

}
