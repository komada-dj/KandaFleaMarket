package dao;

import java.sql.*;
import java.util.*;

import bean.Purchase;

public class PurchaseDAO {

	// データベース接続情報
	private static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static String URL = "jdbc:mysql://localhost/mybookdb";
	private static String USER = "root";
	private static String PASS = "root123";

	private static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASS);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	public ArrayList<Purchase> selectAll() {

		// 変数宣言
		Connection con = null;
		Statement smt = null;

		// return用オブジェクト生成
		ArrayList<Purchase> purchaseList = new ArrayList<Purchase>();

		// SQL文
		String sql = "SELECT * FROM bookinfo ORDER BY profitId";

		try {
			con = getConnection();
			smt = con.createStatement();

			//* SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			// 検索結果を配列に格納
			while (rs.next()) {
				Purchase purchase = new Purchase();
				purchase.setProfitId(rs.getInt("profit_id"));
				purchase.setItemId(rs.getInt("item_id"));
				purchase.setSellerId(rs.getInt("seller_id"));
				purchase.setSellerNickname(rs.getString("seller_nickname"));
				purchase.setItemName(rs.getString("item_name"));
				purchase.setItemTypeId(rs.getInt("item_type_id"));
				purchase.setQuantity(rs.getInt("quantity"));
				purchase.setPrice(rs.getInt("price"));
				purchase.setRemarks(rs.getString("remarks"));
				purchase.setItemStatus(rs.getInt("item_status"));
				purchase.setPicture(rs.getString("picture"));
				purchase.setBuyerId(rs.getInt("buyer_id"));
				purchase.setBuyerNickname(rs.getString("buyer_nickname"));
				purchase.setBuyDate(rs.getString("buy_date"));
				purchase.setPaymentStatus(rs.getInt("payment_status"));
				purchase.setPaymentDate(rs.getString("payment_date"));
				purchase.setSendStatus(rs.getInt("send_status"));
				purchase.setSendDate(rs.getString("send_date"));

				// ArrayListに格納
				purchaseList.add(purchase);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return purchaseList;
	}

	public void insert(Purchase purchase) {

		Connection con = null;
		Statement smt = null;

		int count = 0;

		// SQL文
		//チェックお願いします！！！！！！！！！！！！！！！
		String sql = "INSERT INTO profitinfo VALUES('"
				+ purchase.getProfitId() + "','"
				+ purchase.getItemId() + "',"
				+ purchase.getSellerId() + "',"
				+ purchase.getSellerNickname() + "',"
				+ purchase.getItemName() + "',"
				+ purchase.getItemTypeId() + "',"
				+ purchase.getQuantity() + "',"
				+ purchase.getPrice() + "',"
				+ purchase.getRemarks() + "',"
				+ purchase.getItemStatus() + "',"
				+ purchase.getPicture() + "',"
				+ purchase.getBuyerId() + "',"
				+ purchase.getBuyerNickname() + "',"
				+ purchase.getBuyDate() + "',"
				+ purchase.getPaymentStatus() + "',"
				+ purchase.getPaymentDate() + "',"
				+ purchase.getSendStatus() + "',"
				+ purchase.getSendDate() + "',"
				+ ")";

		try {
			con = getConnection();
			smt = con.createStatement();

			// SQLをDBへ発行
			count = smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	public Purchase selectByItemId(String itemId) {

		Connection con = null;
		Statement smt = null;

		// 検索した書籍情報を格納するBookオブジェクトを生成
		Purchase purchase = new Purchase();

		// SQL文
		//チェックお願いします！！！！！！！！！！！！！！！
		String sql = "SELECT ??????? FROM profitinfo WHERE isbn = '" + itemId + "'";

		try {
			// DBに接続
			con = getConnection();
			smt = con.createStatement();

			//* SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			// 検索結果をbookに格納
			while (rs.next()) {
				purchase.setProfitId(rs.getInt("profit_id"));
				purchase.setItemId(rs.getInt("item_id"));
				purchase.setSellerId(rs.getInt("seller_id"));
				purchase.setSellerNickname(rs.getString("seller_nickname"));
				purchase.setItemName(rs.getString("item_name"));
				purchase.setItemTypeId(rs.getInt("item_type_id"));
				purchase.setQuantity(rs.getInt("quantity"));
				purchase.setPrice(rs.getInt("price"));
				purchase.setRemarks(rs.getString("remarks"));
				purchase.setItemStatus(rs.getInt("item_status"));
				purchase.setPicture(rs.getString("picture"));
				purchase.setBuyerId(rs.getInt("buyer_id"));
				purchase.setBuyerNickname(rs.getString("buyer_nickname"));
				purchase.setBuyDate(rs.getString("buy_date"));
				purchase.setPaymentStatus(rs.getInt("payment_status"));
				purchase.setPaymentDate(rs.getString("payment_date"));
				purchase.setSendStatus(rs.getInt("send_status"));
				purchase.setSendDate(rs.getString("send_date"));
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return purchase;
	}

	public Purchase selectByProfitId(String profitId) {

		Connection con = null;
		Statement smt = null;

		// 検索した書籍情報を格納するBookオブジェクトを生成
		Purchase purchase = new Purchase();

		// SQL文
		//チェックお願いします！！！！！！！！！！！！！！！
		String sql = "SELECT ???????? FROM profitinfo WHERE isbn = '" + profitId + "'";

		try {
			// DBに接続
			con = getConnection();
			smt = con.createStatement();

			//* SQL文発行
			ResultSet rs = smt.executeQuery(sql);

			// 検索結果をbookに格納
			while (rs.next()) {
				purchase.setProfitId(rs.getInt("profit_id"));
				purchase.setItemId(rs.getInt("item_id"));
				purchase.setSellerId(rs.getInt("seller_id"));
				purchase.setSellerNickname(rs.getString("seller_nickname"));
				purchase.setItemName(rs.getString("item_name"));
				purchase.setItemTypeId(rs.getInt("item_type_id"));
				purchase.setQuantity(rs.getInt("quantity"));
				purchase.setPrice(rs.getInt("price"));
				purchase.setRemarks(rs.getString("remarks"));
				purchase.setItemStatus(rs.getInt("item_status"));
				purchase.setPicture(rs.getString("picture"));
				purchase.setBuyerId(rs.getInt("buyer_id"));
				purchase.setBuyerNickname(rs.getString("buyer_nickname"));
				purchase.setBuyDate(rs.getString("buy_date"));
				purchase.setPaymentStatus(rs.getInt("payment_status"));
				purchase.setPaymentDate(rs.getString("payment_date"));
				purchase.setSendStatus(rs.getInt("send_status"));
				purchase.setSendDate(rs.getString("send_date"));
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return purchase;
	}

	public void updatePay(Purchase purchase) {

		Connection con = null;
		Statement smt = null;

		int count = 0;

		// SQL文
		//チェックお願いします！！！！！！！！！！！！！！
		String sql = "INSERT INTO profitinfo VALUES('"
				+ purchase.getProfitId() + "','"
				+ purchase.getItemId() + "',"
				+ purchase.getSellerId() + "',"
				+ purchase.getSellerNickname() + "',"
				+ purchase.getItemName() + "',"
				+ purchase.getItemTypeId() + "',"
				+ purchase.getQuantity() + "',"
				+ purchase.getPrice() + "',"
				+ purchase.getRemarks() + "',"
				+ purchase.getItemStatus() + "',"
				+ purchase.getPicture() + "',"
				+ purchase.getBuyerId() + "',"
				+ purchase.getBuyerNickname() + "',"
				+ purchase.getBuyDate() + "',"
				+ purchase.getPaymentStatus() + "',"
				+ purchase.getPaymentDate() + "',"
				+ purchase.getSendStatus() + "',"
				+ purchase.getSendDate() + "',"
				+ ")";

		try {
			con = getConnection();
			smt = con.createStatement();

			// SQLをDBへ発行
			count = smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	public void updateSend(Purchase purchase) {

		Connection con = null;
		Statement smt = null;

		int count = 0;

		// SQL文
		//チェックお願いします！！！！！！！！！！！！！！
		String sql = "INSERT INTO profitinfo VALUES('"
				+ purchase.getProfitId() + "','"
				+ purchase.getItemId() + "',"
				+ purchase.getSellerId() + "',"
				+ purchase.getSellerNickname() + "',"
				+ purchase.getItemName() + "',"
				+ purchase.getItemTypeId() + "',"
				+ purchase.getQuantity() + "',"
				+ purchase.getPrice() + "',"
				+ purchase.getRemarks() + "',"
				+ purchase.getItemStatus() + "',"
				+ purchase.getPicture() + "',"
				+ purchase.getBuyerId() + "',"
				+ purchase.getBuyerNickname() + "',"
				+ purchase.getBuyDate() + "',"
				+ purchase.getPaymentStatus() + "',"
				+ purchase.getPaymentDate() + "',"
				+ purchase.getSendStatus() + "',"
				+ purchase.getSendDate() + "',"
				+ ")";

		try {
			con = getConnection();
			smt = con.createStatement();

			// SQLをDBへ発行
			count = smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}


}
